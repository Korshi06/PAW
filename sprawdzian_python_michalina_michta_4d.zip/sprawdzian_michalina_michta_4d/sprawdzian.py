import datetime
import json
import os
from models.Student import Student
from models.Teacher import Teacher
from models.Subject import Subject
from models.Grades import Grades
from year_grade import year_grade

__copyright__ = "Zespół Szkół Komunikacji w Poznaniu"
__author__ = "Michałina Michta"

def main():
    teachers: list[Teacher] = []
    subjects: list[Subject] = []
    students: list[Student] = []
    grades_list: list[Grades] = []

    with open('teachers.txt', 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 3:
                _id = int(parts[0])
                name = parts[1]
                surname = ' '.join(parts[2:])
                teachers.append(Teacher(_id, name, surname))

    with open('subjects.txt', 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 3:
                _id = int(parts[0])
                name = ' '.join(parts[1:-1])
                teacher_id = int(parts[-1])
                # Find teacher
                teacher = next((t for t in teachers if t.id == teacher_id), None)
                if teacher:
                    subjects.append(Subject(_id, name, teacher))

    with open('students.txt', 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 4:
                _id = int(parts[0])
                first_name = parts[1]
                last_name = ' '.join(parts[2:-1])
                birth_date_str = parts[-1]
                try:
                    birth_date = datetime.datetime.strptime(birth_date_str, '%Y-%m-%d').date()
                    students.append(Student(_id, first_name, last_name, birth_date))
                except ValueError:
                    continue

    with open('grades.txt', 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 3:
                student_id = int(parts[0])
                subject_id = int(parts[1])
                grades_str = parts[2]

                student = next((s for s in students if s.id == student_id), None)
                subject = next((s for s in subjects if s.id == subject_id), None)

                if student and subject:
                    grades_obj = next(
                        (g for g in grades_list if g.student.id == student_id and g.subject.id == subject_id), None)
                    if not grades_obj:
                        grades_obj = Grades(student, subject)
                        grades_list.append(grades_obj)

                    for grade in grades_str.split(','):
                        try:
                            grades_obj.add_grade(int(grade))
                        except ValueError:
                            continue

    print("Oceny i średnie poszczególnych uczniów")
    print()

    students_data = {}

    for student in students:
        student_grades = [g for g in grades_list if g.student.id == student.id]
        if not student_grades:
            continue

        print(f"{student}:")
        student_data = {}

        for grade_obj in student_grades:
            subject_name = grade_obj.subject.name
            grades = grade_obj.get_grades()
            average = grade_obj.get_average()
            final_grade = year_grade(average)

            print(f"{subject_name}:")
            print(f"Oceny: {', '.join(map(str, grades))}")
            print(f"Średnia: {average:.2f}")
            print(f"Ocena końcowa: {final_grade}")
            print()

            student_data[subject_name] = {
                "Oceny": ", ".join(map(str, grades)),
                "Srednia": round(average, 2),
                "Ocena roczna": final_grade
            }

        students_data[str(student)] = student_data
        print()

    os.makedirs('jsonData', exist_ok=True)
    with open('jsonData/students.json', 'w', encoding='utf-8') as f:
        json.dump(students_data, f, indent=4, ensure_ascii=False)

    print("=" * 50)
    print()

    subjects_data = {}

    for subject in subjects:
        subject_grades = [g for g in grades_list if g.subject.id == subject.id]
        if not subject_grades:
            continue

        print(f"{subject.name}:")
        print(f"   Nauczyciel: {subject.teacher}")

        all_grades = []
        for grade_obj in subject_grades:
            all_grades.extend(grade_obj.get_grades())

        print(f"   Oceny: {', '.join(map(str, all_grades))}")
        average = sum(all_grades) / len(all_grades) if all_grades else 0
        print(f"   Średnia: {average:.2f}")
        print()

        subjects_data[subject.name] = {
            "Nauczyciel": str(subject.teacher),
            "Oceny": all_grades,
            "Srednia": round(average, 2)
        }

    with open('jsonData/subjects.json', 'w') as f:
        json.dump(subjects_data, f, indent=4, ensure_ascii=False)


if __name__ == "__main__":
    main()