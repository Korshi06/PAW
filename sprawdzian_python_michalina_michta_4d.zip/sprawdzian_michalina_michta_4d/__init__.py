__copyright__ = "Zespół Szkół Komunikacji"  
__author__ = "Michalina Michta 4d"  
